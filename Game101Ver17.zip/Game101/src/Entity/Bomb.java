/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

import Tiles.Tiles;
import game101.GamePanel;
import game101.KeyHandler;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 *
 * @author ศิรเมศร์
 */
public class Bomb {
    private KeyHandler keyH;
    private BufferedImage bomb;
    private Tiles[] tile;
    private GamePanel gp;
    int bombx;
    int bomby;
            
    public Bomb(int x,int y){
        bombx=x;
        bomby=y;
        getTileImage();
    }
    public void getTileImage(){
        try{
            bomb=ImageIO.read(getClass().getResourceAsStream("/res/tiles/bomb.png"));
            
        }catch(IOException ex){
            ex.printStackTrace();
        }
    }
    public void drawbomb(Graphics2D g2){
        g2.drawImage(bomb,bombx,bomby,48,48,null);
    }
    
    
}
