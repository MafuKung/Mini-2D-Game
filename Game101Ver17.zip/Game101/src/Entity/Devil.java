/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

import Block.Dirth;
import Block.Lava;
import Block.Obsidian;
import Tiles.TilesManager;
import game101.EndScreen;
import game101.GamePanel;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/**
 *
 * @author yodsapat
 */

public class Devil extends Entity {
    GamePanel gp;
    int topleftX=WorldX;
    int topleftY=WorldY;
    int toprightX=WorldX+48;
    int toprightY=WorldY;
    int downleftX=WorldX;
    int downleftY=WorldY+48;
    int downrightX=WorldX+48;
    int downrightY=WorldY+48;
    int hitBoxTopLeftX = (topleftX/48)*48;
    int hitBoxTopLeftY = (topleftY/48)*48;
    int hitBoxTopRightX =  (toprightX/48)*48;
    int hitBoxTopRightY =  (toprightY/48)*48;
    int hitBoxDownLeftX =  (downleftX/48)*48;
    int hitBoxDownLeftY =  (downleftY/48)*48;
    int hitBoxDownRightX =  (downrightX/48)*48;
    int hitBoxDownRightY =  (downrightY/48)*48;
    boolean checker=true;
    public boolean alive=true;
    
    public Devil (GamePanel gp){
        this.gp=gp;
        setDefaultValues();
        getDevilImage();
    }
    
    public void setDefaultValues(){
         WorldX=(int) (Math.random() * 1100);
         WorldY=(int) (Math.random() * 300);
         topleftX=WorldX;
         topleftY=WorldY;
         toprightX=WorldX+48;
         toprightY=WorldY;
         downleftX=WorldX;
         downleftY=WorldY+48;
         downrightX=WorldX+48;
         downrightY=WorldY+48;
         
         //speed=4; //walking 1 time = 4px
         direction="right";
         fallable=true;
    }
    
    public void getDevilImage(){
        try {
            right1=ImageIO.read(getClass().getResourceAsStream("/res/player/Devil-1.png"));
            right2=ImageIO.read(getClass().getResourceAsStream("/res/player/Devil-2.png"));
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    EndScreen endScreen = new EndScreen();
    public void update(TilesManager tm){
    //Create animation
    spriteCounter++;
        if (spriteCounter>15d){
            if(spriteNum==1){
                spriteNum=2;
            }
            else if(spriteNum==2){
                spriteNum=1;
            }
            spriteCounter=0;            
        }
        for(Dirth i:tm.array_dirth){
            if(48*(WorldX/48)==i.getX()&& 48*(WorldY/48)+48==i.getY()){
                for(Dirth j:tm.array_dirth){
                    if(48*(WorldX/48)+48==j.getX()&& 48*(WorldY/48)+48==j.getY()){
                        WorldY+=2;
                        topleftX=WorldX;
                        topleftY=WorldY;
                        toprightX=WorldX+48;
                        toprightY=WorldY;
                        downleftX=WorldX;
                        downleftY=WorldY+48;
                        downrightX=WorldX+48;
                        downrightY=WorldY+48;
                    }
                }
            }
        }
        this.collision(tm);
        if(alive == false && checker==true){
            endScreen.setVisible(true);
            gp.dispose();
            checker=false;
        }
        
    }
    
    public void draw(Graphics2D g2){
    //g2.setColor(Color.black);
    //g2.fillRect(x, y, gp.tileSize, gp.tileSize);
    BufferedImage image=null;
    switch(direction){
        case "right":
            if (spriteNum==1){
                image=right1;
            }
            if (spriteNum==2){
                image=right2;
            }
            break;
    }
    g2.drawImage(image,WorldX,WorldY,gp.tileSize,gp.tileSize,null);
    }
    
    /*public void fallEntity(GamePanel gp,Graphics2D g2){
        if (){
        
        }
    }*/
    
public  void collision(TilesManager tm){
        boolean checking =false;
         hitBoxTopLeftX = (topleftX/48)*48;
         hitBoxTopLeftY = (topleftY/48)*48;
         hitBoxTopRightX =  (toprightX/48)*48;
         hitBoxTopRightY =  (toprightY/48)*48;
         hitBoxDownLeftX =  (downleftX/48)*48;
         hitBoxDownLeftY =  (downleftY/48)*48;
         hitBoxDownRightX =  (downrightX/48)*48;
         hitBoxDownRightY =  (downrightY/48)*48;
        for(Lava lava :tm.array_lava){
            if(lava.hasBlock(hitBoxTopLeftX, hitBoxTopLeftY) || lava.hasBlock(hitBoxTopRightX, hitBoxTopRightY) || lava.hasBlock(hitBoxDownLeftX, hitBoxDownLeftY) ||lava.hasBlock(hitBoxDownRightX, hitBoxDownRightY)){
                alive = false;
            }
        }
        if(tm.array_obsidian.size() != 0){
            for(Obsidian obsidian :tm.array_obsidian){
            if(obsidian.hasBlock(hitBoxTopLeftX, hitBoxTopLeftY) || obsidian.hasBlock(hitBoxTopRightX, hitBoxTopRightY) || obsidian.hasBlock(hitBoxDownLeftX, hitBoxDownLeftY) ||obsidian.hasBlock(hitBoxDownRightX, hitBoxDownRightY)){
                alive = false;
            }
        }
        }
}
    
    
}

