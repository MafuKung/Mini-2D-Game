/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

import Tiles.TilesManager;
import game101.GamePanel;
import game101.KeyHandler;
import game101.MouseHandler;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import Block.Dirth;
import Block.Lava;
import Block.Obsidian;
import game101.DefeatScreen;
import game101.EndScreen;
import java.util.ArrayList;
/**
 *
 * @author yodsapat
 */

public class Player extends Entity {
    GamePanel gp;
    KeyHandler keyH;
    int topleftX=WorldX;
    int topleftY=WorldY;
    int toprightX=WorldX+48;
    int toprightY=WorldY;
    int downleftX=WorldX;
    int downleftY=WorldY+48;
    int downrightX=WorldX+48;
    int downrightY=WorldY+48;
    public boolean alive=true;
    
    public Player(GamePanel gp, KeyHandler keyH){
        this.gp=gp;
        this.keyH=keyH;
        setDefaultValues();
        getPlayerImage();
        
    }
    
    
    public void setDefaultValues(){
         WorldX=(int) (Math.random() * 600);
         WorldY=(int) (Math.random() * 350);
         topleftX=WorldX;
         topleftY=WorldY;
         toprightX=WorldX+48;
         toprightY=WorldY;
         downleftX=WorldX;
         downleftY=WorldY+48;
         downrightX=WorldX+48;
         downrightY=WorldY+48;
         speed=4; //walking 1 time = 4px
         direction="right";
         //inihiHitbox();
    }
    
    public void getPlayerImage(){
        try {
            up1=ImageIO.read(getClass().getResourceAsStream("/res/player/Player-up-1.png"));
            up2=ImageIO.read(getClass().getResourceAsStream("/res/player/Player-up-2.png"));
            down1=ImageIO.read(getClass().getResourceAsStream("/res/player/Player-down-1.png"));
            down2=ImageIO.read(getClass().getResourceAsStream("/res/player/Player-down-2.png"));
            right1=ImageIO.read(getClass().getResourceAsStream("/res/player/Player-right-1.png"));
            right2=ImageIO.read(getClass().getResourceAsStream("/res/player/Player-right-2.png"));
            left1=ImageIO.read(getClass().getResourceAsStream("/res/player/Player-left-1.png"));
            left2=ImageIO.read(getClass().getResourceAsStream("/res/player/Player-left-2.png"));
            bomb =ImageIO.read(getClass().getResourceAsStream("/res/tiles/bomb.png"));
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    
    DefeatScreen defeatScreen = new DefeatScreen();
    boolean checker=true;
    public void update(TilesManager tm,MouseHandler m){
        //updateHitbox();
        int topleftX=WorldX;
        int topleftY=WorldY;
        toprightX=topleftX+48;
        toprightY=topleftY;
        downleftX=topleftX;
        downleftY=topleftY+48;
        downrightX=topleftX+48;
        downrightY=topleftY+48;
        
        if(alive == false && checker==true){
            defeatScreen.setVisible(true);
            gp.dispose();
            checker=false;
        }
        
        if(keyH.upPressed==true){
            direction="up";
            //System.out.println("up");
            if(WorldY>0 && collision(direction,tm)){
            WorldY-=speed;}
            }
        
        else if (keyH.downPressed==true){
            direction="down";
            //System.out.println("down");
            if(WorldY<672 && collision(direction,tm) ){
            WorldY+=speed;}
            }
        
        else if (keyH.rightPressed==true){
            direction="right";
            //System.out.println("right");
            if(WorldX<1152 && collision(direction,tm) ){
            WorldX+=speed;}
            }
        
        else if (keyH.leftPressed==true){
            direction="left";
            //System.out.println("left");
            if(WorldX>0 && collision(direction,tm)){
            WorldX-=speed;}
            }
        else if (keyH.spacePressed==true){
        
        }
        
            
    //collisionOn=false;
    
    //Create animation
    spriteCounter++;
        if (spriteCounter>15d){
            if(spriteNum==1){
                spriteNum=2;
            }
            else if(spriteNum==2){
                spriteNum=1;
            }
            spriteCounter=0;            
        }
        
 
    }
    public void draw(Graphics2D g2){
    //g2.setColor(Color.black);
    //g2.fillRect(x, y, gp.tileSize, gp.tileSize);
    BufferedImage image=null;
    switch(direction){
        case "up":
            if (spriteNum==1){
                image=up1;
            }
            if (spriteNum==2){
                image=up2;
            }
            break;
        case "down":
            if (spriteNum==1){
                image=down1;
            }
            if (spriteNum==2){
                image=down2;
            }
            break;
        case "right":
            if (spriteNum==1){
                image=right1;
            }
            if (spriteNum==2){
                image=right2;
            }
            break;
        case "left":
            if (spriteNum==1){
                image=left1;
            }
            if (spriteNum==2){
                image=left2;
            }
            break;
    }
    g2.drawImage(image,WorldX,WorldY,gp.tileSize,gp.tileSize,null);
    }
    
    public boolean collision(String direction,TilesManager tm){
        boolean check =false;
        int hitBoxTopLeftX = (topleftX/48)*48;
        int hitBoxTopLeftY = (topleftY/48)*48;
        int hitBoxTopRightX =  (toprightX/48)*48;
        int hitBoxTopRightY =  (toprightY/48)*48;
        int hitBoxDownLeftX =  (downleftX/48)*48;
        int hitBoxDownLeftY =  (downleftY/48)*48;
        int hitBoxDownRightX =  (downrightX/48)*48;
        int hitBoxDownRightY =  (downrightY/48)*48;
        for(Lava lava :tm.array_lava){
            if(lava.hasBlock(hitBoxTopLeftX, hitBoxTopLeftY) || lava.hasBlock(hitBoxTopRightX, hitBoxTopRightY) || lava.hasBlock(hitBoxDownLeftX, hitBoxDownLeftY) ||lava.hasBlock(hitBoxDownRightX, hitBoxDownRightY)){
                alive = false;
            }
                
        }
        
        switch(direction){
            case "up":
                /*System.out.println("topleftX"+topleftX);
                System.out.println("topleftY"+topleftY);
                System.out.println("toprightX"+toprightX);
                System.out.println("toprightY"+toprightY);
                System.out.println("---------------------------");*/
                for(Dirth i:tm.array_dirth){
                if(i.getX()-2 <= topleftX && topleftX<=i.getX()+50 && i.getY()-2 <=topleftY && topleftY<=i.getY()+50){
                    for(Dirth j:tm.array_dirth){
                        if(j.getX()-2 <= toprightX && toprightX<=j.getX()+50 && j.getY()-2 <=toprightY && toprightY<=j.getY()+50){
                            check= true;
                    
                }
                }
                }
                }
                
                break;
            case "down":
                for(Dirth i:tm.array_dirth){
                if(i.getX()-2 <= downleftX && downleftX<=i.getX()+50 && i.getY()-2 <=downleftY && downleftY<=i.getY()+50){
                    for(Dirth j:tm.array_dirth){
                if(j.getX()-2 <= downrightX && downrightX<=j.getX()+50 && j.getY()-2 <=downrightY && downrightY<=j.getY()+50){
                    check= true;
                }
                }
                }
                }
                break;
            case "right":
                for(Dirth i:tm.array_dirth){
                if(i.getX()-2 <= toprightX && toprightX<=i.getX()+50 && i.getY()-2 <=toprightY && toprightY<=i.getY()+50){
                    for(Dirth j:tm.array_dirth){
                if(j.getX()-2 <= downrightX && downrightX<=j.getX()+50 && j.getY()-2 <=downrightY && downrightY<=j.getY()+50){
                    check= true;
                }
                }
                }
                }
                break;
                
            case "left":
               for(Dirth i:tm.array_dirth){
                if(i.getX()-2 <= topleftX && topleftX<=i.getX()+50 && i.getY()-2 <=topleftY && topleftY<=i.getY()+50){
                    for(Dirth j:tm.array_dirth){
                if(j.getX()-2 <= downleftX && downleftX<=j.getX()+50 && j.getY()-2 <=downleftY && downleftY<=j.getY()+50){
                    check= true;
                    
                }
                }
                }
                }
                break;
        }
        return check;
    }
    
}
