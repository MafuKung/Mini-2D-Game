/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;

/**
 *
 * @author yodsapat
 */
public class Entity {
    public int WorldX,WorldY;
    public int speed;
    public String direction;
    public BufferedImage up1,up2,down1,down2,left1,left2,right1,right2,bomb;
    // create animation
    public int spriteCounter=0;
    public int spriteNum=1;
    public boolean collisionOn=false;
    public boolean fallable=false;
    //Rectangle hitbox;
    
    /*public void inihiHitbox(){
        hitbox =new Rectangle(WorldX-8,WorldY-10,32,30);
    }
    public void updateHitbox(){
        hitbox =new Rectangle(WorldX-8,WorldY-10,32,30);
    }*/
            
    
}
