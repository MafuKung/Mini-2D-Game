/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Block;

import game101.GamePanel;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

/**
 *
 * @author ศิรเมศร์
 */
public abstract class Block {
    public BufferedImage image;
    GamePanel gp;
    int x;
    int y;

    
    public Block(GamePanel gp,int x,int y){
        this.gp=gp;
        this.x = x;
        this.y = y;
    }
    
    public abstract void create(Graphics2D g2);
    
    public boolean hasBlock(int x , int y){
        boolean retur_n = false;
        if(this.x == x && this.y == y){
            retur_n = true;
        }
        return retur_n;
    }
    
    public int getX(){
        return x;
    }
    public int getY(){
        return y;
    }
        
    
}