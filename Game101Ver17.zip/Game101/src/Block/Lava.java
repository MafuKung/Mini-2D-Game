/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Block;

import Tiles.Tiles;
import Tiles.TilesManager;
import java.awt.image.BufferedImage;
import game101.GamePanel;
import java.awt.Graphics2D;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 *
 * @author ศิรเมศร์
 */
public class Lava extends Block{
    private BufferedImage lavaImage;
    private Tiles[] tile;
            
    public Lava(GamePanel gp,int x,int y){
        super(gp,x,y);
        tile =new Tiles[10]; 
        getTileImage();
        
    }
    
    public void getTileImage(){
        try{
            lavaImage=ImageIO.read(getClass().getResourceAsStream("/res/tiles/Lava.png"));
            
        }catch(IOException ex){
            ex.printStackTrace();
        }
    }
    
    /*public void create(Graphics2D g2){
        int col =0;
        int row =0;
        int x=800;
        int y=400;

        while(x<1000){
            g2.drawImage(lavaImage,x,y,gp.tileSize,gp.tileSize,null);
            x+=gp.tileSize;
            if(x>1000){
                x = 800;
                y+=gp.tileSize;
                if(y>500) break;
            }
        }
    }*/
    
    public void create(Graphics2D g2){
        g2.drawImage(lavaImage,x,y,gp.tileSize,gp.tileSize,null);

    }
    
    
    
}
