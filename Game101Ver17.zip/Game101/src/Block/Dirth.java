/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Block;

import Tiles.Tiles;
import game101.GamePanel;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 *
 * @author ศิรเมศร์
 */
public class Dirth extends Block{
    private BufferedImage dirthImage;
    private Tiles[] tile;
    
    public Dirth(GamePanel gp,int x,int y){
        super(gp,x,y);
        tile =new Tiles[10]; 
        getTileImage();
        
    }
    
    public void getTileImage(){
        try{
            dirthImage=ImageIO.read(getClass().getResourceAsStream("/res/tiles/Dirth.png"));
            
        }catch(IOException ex){
            ex.printStackTrace();
        }
    }
    
    public void create(Graphics2D g2){
        g2.drawImage(dirthImage,x,y,gp.tileSize,gp.tileSize,null);

    }
    
}
