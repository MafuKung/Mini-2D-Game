/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package game101;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 *
 * @author yodsapat
 */
public class KeyHandler implements KeyListener { //Listener interface to receiving kb events
    
    public boolean upPressed, downPressed,leftPressed,rightPressed,spacePressed;
    
    
    @Override
    public void keyTyped(KeyEvent e) {
    }   
    

    @Override
    public void keyPressed(KeyEvent e) {
       int code =e.getKeyCode(); //return keyCode associated with the key in this event
       if (code==KeyEvent.VK_W){ //if user press W
           upPressed=true;
           //System.out.println("W");
       }
       if (code==KeyEvent.VK_A){ //if user press A
           leftPressed=true;
           //System.out.println("A");
       }
       if (code==KeyEvent.VK_S){ //if user press S
           downPressed=true;
           //System.out.println("S");
       }
       if (code==KeyEvent.VK_D){ //if user press D
           rightPressed=true;
           //System.out.println("D");
       }
       if (code==KeyEvent.VK_SPACE){
           spacePressed=true;
       }
       
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int code =e.getKeyCode();
        if (code==KeyEvent.VK_W){ //if user press W
           upPressed=false;
       }
       if (code==KeyEvent.VK_A){ //if user press A
           leftPressed=false;
       }
       if (code==KeyEvent.VK_S){ //if user press S
           downPressed=false;
       }
       if (code==KeyEvent.VK_D){ //if user press D
           rightPressed=false;
       }
       if (code==KeyEvent.VK_SPACE){
           //spacePressed=false;
       }
    }
    
}
