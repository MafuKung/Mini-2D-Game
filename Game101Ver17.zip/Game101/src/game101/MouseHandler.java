/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package game101;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.MouseInfo;
import java.util.ArrayList;
import Tiles.TilesManager;

/**
 *
 * @author yodsapat
 */
public class MouseHandler implements MouseListener,MouseMotionListener {
    boolean dragged;
    int mx;
    int my;
    public ArrayList <Integer> dragXal= new ArrayList<>();
    public ArrayList <Integer> dragYal= new ArrayList<>();
    
    
    @Override
    public void mouseClicked(MouseEvent arg0) {
        dragged=true;
        mx=arg0.getX();
        my=arg0.getY();
        
    }

    @Override
    public void mousePressed(MouseEvent arg0) {
        mx=arg0.getX();
        my=arg0.getY();
    }

    @Override
    public void mouseReleased(MouseEvent arg0) {
        mx=arg0.getX();
        my=arg0.getY();
        
    }

    @Override
    public void mouseEntered(MouseEvent arg0) {
        mx=arg0.getX();
        my=arg0.getY();
    }

    @Override
    public void mouseExited(MouseEvent arg0) {
       mx=arg0.getX();
       my=arg0.getY();
    }

    
    private int getRealX ;
    private int getRealY ;
    
    
    @Override
    public void mouseDragged(MouseEvent arg0) {
        dragged=false;
        
        mx=arg0.getX();
        my=arg0.getY();
        int realx=mx/48;
        int realy=my/48;
        getRealX = realx;
        getRealY = realy;
        if(0<arg0.getX() && arg0.getX()<1200 && 0<arg0.getY() && arg0.getY()<720){
            dragged=true;
        }
        /*dragXal.add(realx);
        dragYal.add(realy);*/
        //System.out.println("Dragged!!");
        
    }
    
    public int getRealX(){
        return getRealX*48;
    }
    
    public int getRealY(){
        return getRealY*48;
    }

    @Override
    public void mouseMoved(MouseEvent arg0) {
        mx=arg0.getX();
        my=arg0.getY();
    }
    
    public boolean getdrag(){
        return dragged;
    }
    
    /*public ArrayList<Integer> getdragX(){return dragXal;}
    public ArrayList<Integer> getdragY(){return dragYal;}*/
    
}
