/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package game101;

import Entity.Devil;
import Entity.Player;
import Tiles.TilesManager;
import Block.Lava;
import Block.Water;
import Entity.Bomb;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;


/**
 *
 * @author yodsapat
 */
public class GamePanel extends JPanel implements Runnable{
    //Screen setting
    final int originalTitleSize=16; //16*16 pixel character
    final int scale=3; //the image size will bigger 3 time from it's original size ex. if monster is 16*16 px it'll be 48*48px in your screen
    
    public final int tileSize=originalTitleSize*scale; //48*48 tile
    public final int maxScreenColum=25;
    public final int maxScreenRow=15;
    /*screen will create from 25 colums and 15 rows ********************
                                                    ********************
                                                    ********************
                                                    ********************
                                                    ********************
                                                    ...15rows
                                                    ******************** */
    
    //the final size of game screen will apear to user is:
    public final int screenwidth=tileSize*maxScreenColum; // 48*25=1200px
    public final int screenHight=tileSize*maxScreenRow; //   48*15=720px
    
    int FPS =60;
    
    
    
    
    KeyHandler keyH=new KeyHandler();
    TilesManager tileM=new TilesManager(this);
    Thread gameThread; //while Thread stared it will keep game running and ****to run thread need to implement Runnable class.*****
    Player player= new Player (this,keyH);
    Devil devil=new Devil(this);
    MouseHandler Mouse=new MouseHandler();
    JPanel p = new JPanel();
    JButton jButton1;
    //set default player position
    
    int playerX=(int) (Math.random() * 600);
    int playerY=(int) (Math.random() * 350);
    int playerSpeed=4; //walking 1 time = 4px
    
    public GamePanel(){
        this.setPreferredSize(new Dimension(screenwidth, screenHight)); //set size of this class
        this.setBackground(Color.pink);
        this.setDoubleBuffered(true); //all drawing from this component will be done in an offscreen painting buffer
        this.addKeyListener(keyH);
        this.setFocusable(true); //GamePanel can be focused to receive key input
        this.addMouseMotionListener(Mouse);
        this.addMouseListener(Mouse);
        
        
            

        
        
    }
    
    public void startGameThread(){
        gameThread =new Thread(this);
        gameThread.start();
        
    }
    
    @Override //when game start thread will automatically called this run method.
    public void run() {
        // we will create game loop!!!
        
        double drawInterval=1000000000/FPS; //Program will draw screen every 1/60=0.016666 sec.
        double delta=0;
        long lastTime=System.nanoTime();
        long currentTime;
        
        while (gameThread!=null){
            
            currentTime=System.nanoTime();
            delta+=(currentTime - lastTime)/drawInterval;
            lastTime=currentTime;
            
            if(delta>=1){
            // 1=Update: update information such as character positions
            
            update();
            // 2=Draw: draw the screen with the updated information
            
            repaint();
            
            delta--;
            }
           
        }
        
    }
    int bombcount=0;
    public void update(){// use for update the information in game in the upper case
        player.update(tileM,Mouse);
        devil.update(tileM);
    }
    
    CopyOnWriteArrayList <Integer> bomxy=new CopyOnWriteArrayList<>();
    
    Timer myTimer;
    int countTimer = 0;
    
    
    @Override
    public void paintComponent(Graphics g){//to draw screen update information
                                //the Graphics parameter is class that have many functions to draw obj. in screen.
        super.paintComponent(g); //need to do this!! to sent data to superclass JPanel
        Graphics2D g2=(Graphics2D) g; //downcasting g to be Graphics2D class, it has more function to use
        tileM.draw(g2); //this line must be add before player.draw(g2) because it will be layer by layer
        tileM.doPath(Mouse,g2);
        tileM.createLava(g2);
        tileM.createWater(g2);
        player.draw(g2);
        devil.draw(g2);
        tileM.colisionLavaWater(g2);
        tileM.afterColisionLavaWater(g2);
        if(keyH.spacePressed==true && bombcount<=2){
            if(bomxy.size()<=2){
                bomxy.add(player.WorldX);
                bomxy.add(player.WorldY);
            }
            
            
            Bomb bomb=new Bomb(bomxy.get(0),bomxy.get(1));
            bomb.drawbomb(g2);
            
            Timer t = new Timer();
    TimerTask task = new TimerTask(){
      public void run()
      {
          
          if(countTimer == 0){
              if(bomxy.get(0)-48 < player.WorldX && player.WorldX < bomxy.get(0)+96 && bomxy.get(1)-48 < player.WorldY && player.WorldY < bomxy.get(1)+96){
                  player.alive = false;
              }
              else if(bomxy.get(0)-48 < devil.WorldX && devil.WorldX < bomxy.get(0)+96 && bomxy.get(1)-48 < devil.WorldY && devil.WorldY < bomxy.get(1)+96){
                  devil.alive = false;
              }
              try {
                File mFile = new File("src\\res\\player\\BombSound.wav");
                Clip clip = AudioSystem.getClip();
                clip.open(AudioSystem.getAudioInputStream(mFile));
                clip.start();
                    }    catch (Exception e1) {
                        System.out.println(e1);
                    }
              
          }
      }
      
    };
    
    t.schedule(task, 3000);
            
            
        }
        
        
        
        
        g2.dispose();
        
    }
        //from 50-this lines, make game update and repaint every sec.

    public void dispose() {
        Window win = SwingUtilities.getWindowAncestor(this); 
        win.dispose();
    }
    
}   

