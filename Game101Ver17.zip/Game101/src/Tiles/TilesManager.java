/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tiles;

import Block.Dirth;
import Entity.Player;
import Block.Lava;
import Block.Obsidian;
import Block.Water;
import Entity.Bomb;
import game101.DefeatScreen;
import game101.GamePanel;
import game101.KeyHandler;
import game101.MouseHandler;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.imageio.ImageIO;

/**
 *
 * @author yodsapat
 */
public class TilesManager extends Rectangle {
    GamePanel gp;
    Tiles[]tile;
    int x;
    int y;
    MouseHandler m;
    Graphics g;
    KeyHandler keyH;
    
    public TilesManager(GamePanel gp){
        this.gp=gp;
        tile =new Tiles[10]; //Create 10 type of tiles
        getTileImage();
        this.g = g;
        
    }
    public void getTileImage(){
        try{
            tile[0]=new Tiles();
            tile[0].image=ImageIO.read(getClass().getResourceAsStream("/res/tiles/Dirth.png"));
            
            tile[1]=new Tiles();
            tile[1].image=ImageIO.read(getClass().getResourceAsStream("/res/tiles/Stone.png"));
            tile[1].collision=true;
            
            tile[2]=new Tiles();
            tile[2].image=ImageIO.read(getClass().getResourceAsStream("/res/tiles/Water.png"));
            
            tile[3]=new Tiles();
            tile[3].image=ImageIO.read(getClass().getResourceAsStream("/res/tiles/Lava.png"));
            tile[3].collision=true;
            
            tile[4]=new Tiles();
            tile[4].image=ImageIO.read(getClass().getResourceAsStream("/res/tiles/Obsidian.png"));
            tile[4].collision=true;
            
            tile[5]=new Tiles();
            tile[5].image=ImageIO.read(getClass().getResourceAsStream("/res/tiles/bomb.png"));
            tile[5].collision=true;
            
        }catch(IOException ex){
            ex.printStackTrace();
        }
    }
    
    public void draw(Graphics2D g2){
        //g2.drawImage(tile[0].image,0,0,gp.tileSize,gp.tileSize,null);
        //g2.drawImage(tile[1].image,48,0,gp.tileSize,gp.tileSize,null);
        //The upper comment line is for test some image to put in game
        int col =0;
        int row =0;
        int x=0;
        int y=0;
        while(col<gp.maxScreenColum && row<gp.maxScreenRow){
            g2.drawImage(tile[1].image,x,y,gp.tileSize,gp.tileSize,null);
            col++;
            x+=gp.tileSize;
            if(col==gp.maxScreenColum){
                col=0;
                x=0;
                row++;
                y+=gp.tileSize;
            }
        }
    }
    
    public CopyOnWriteArrayList<Water> array_water = new CopyOnWriteArrayList<Water>();
    int x_waterX=(int) (Math.random() * 500)/48;
    int y_waterY=(int) (Math.random() * 604)/48;
    
    public void createWater(Graphics2D g2){
        int waterX=x_waterX;
        int waterY=y_waterY;
        int countWater = 0;
        if(array_dirth.size()==0){
            array_water.removeAll(array_water);
            for(int j = 0 ; j < 2 ; j++){
                for(int i =0 ; i < 3 ; i++){
                    Water water = new Water(gp,(waterX*48)+(gp.tileSize*i),(waterY*48)+(gp.tileSize*j));
                    array_water.add(water);
                    array_water.get(countWater).create(g2);
                    countWater++;
                    
                }
            }
        }
        
        //-----------------------
        
        if(array_dirth.size()!=0){
            for(int i = 0 ; i < array_water.size() ; i++){
                for(Dirth j:array_dirth){
                    int checkDown = 0 ;
                    for(int k = 0 ; k < array_water.size() ; k++){
                        if( array_water.get(k).hasBlock((array_water.get(i)).getX(), (array_water.get(i)).getY() + 48) ){ 
                            checkDown = 1;
                        }
                    }
                    if(checkDown == 0 && j.hasBlock((array_water.get(i)).getX(), (array_water.get(i)).getY() + 48)){
                        Water water = new Water(gp,(array_water.get(i)).getX(),(array_water.get(i)).getY() + 48);
                        array_water.set(i,water);
                    }
                    
                    int checkRight = 0 ;
                    for(int k = 0 ; k < array_water.size() ; k++){
                        if( array_water.get(k).hasBlock((array_water.get(i)).getX() + 48, (array_water.get(i)).getY()) ){ 
                            checkRight = 1;
                        }
                    }
                    if(checkRight == 0 && j.hasBlock((array_water.get(i)).getX() + 48, (array_water.get(i)).getY() )){
                        Water water = new Water(gp,(array_water.get(i)).getX() + 48,(array_water.get(i)).getY());
                        array_water.set(i,water);
                    }
                    
                    int checkLeft = 0 ;
                    for(int k = 0 ; k < array_water.size() ; k++){
                        if( array_water.get(k).hasBlock((array_water.get(i)).getX() - 48, (array_water.get(i)).getY()) ){ 
                            checkLeft = 1;
                        }
                    }
                    if(checkLeft == 0 && j.hasBlock((array_water.get(i)).getX() - 48, (array_water.get(i)).getY() )){
                        Water water = new Water(gp,(array_water.get(i)).getX() - 48,(array_water.get(i)).getY());
                        array_water.set(i,water);
                    }
                    
                }
            }
            for(Water water : array_water){
                water.create(g2);
            }
        }
    }
    
    
    
    
    public CopyOnWriteArrayList<Lava> array_lava = new CopyOnWriteArrayList<Lava>();
    int x_lavaX=(int) (600+Math.random() * 500)/48;
    int y_lavaY=(int) (500+Math.random() * 100)/48;
    
    public void createLava(Graphics2D g2){
        int countLava = 0;
        int lavaX=x_lavaX;
        int lavaY=y_lavaY;
        
        
        if(array_dirth.size()==0){
            array_lava.removeAll(array_lava);
            for(int j = 0 ; j < 2 ; j++){
                for(int i =0 ; i < 3 ; i++){
                    Lava lava = new Lava(gp,(lavaX*48)+(gp.tileSize*i),(lavaY*48)+(gp.tileSize*j));
                    array_lava.add(lava);
                    array_lava.get(countLava).create(g2);
                    countLava++;
                }
            }
        }
        
        //-----------------------
        
        if(array_dirth.size()!=0){
            for(int i = 0 ; i < array_lava.size() ; i++){
                for(Dirth j:array_dirth){
                    int checkDown = 0 ;
                    for(int k = 0 ; k < array_lava.size() ; k++){
                        if( array_lava.get(k).hasBlock((array_lava.get(i)).getX(), (array_lava.get(i)).getY() + 48) ){ 
                            checkDown = 1;
                        }
                    }
                    if(checkDown == 0 && j.hasBlock((array_lava.get(i)).getX(), (array_lava.get(i)).getY() + 48)){
                        Lava lava = new Lava(gp,(array_lava.get(i)).getX(),(array_lava.get(i)).getY() + 48);
                        array_lava.set(i,lava);
                    }
                    
                    int checkRight = 0 ;
                    for(int k = 0 ; k < array_lava.size() ; k++){
                        if( array_lava.get(k).hasBlock((array_lava.get(i)).getX() + 48, (array_lava.get(i)).getY()) ){ 
                            checkRight = 1;
                        }
                    }
                    if(checkRight == 0 && j.hasBlock((array_lava.get(i)).getX() + 48, (array_lava.get(i)).getY() )){
                        Lava lava = new Lava(gp,(array_lava.get(i)).getX() + 48,(array_lava.get(i)).getY());
                        array_lava.set(i,lava);
                    }
                    
                    int checkLeft = 0 ;
                    for(int k = 0 ; k < array_lava.size() ; k++){
                        if( array_lava.get(k).hasBlock((array_lava.get(i)).getX() - 48, (array_lava.get(i)).getY()) ){ 
                            checkLeft = 1;
                        }
                    }
                    if(checkLeft == 0 && j.hasBlock((array_lava.get(i)).getX() - 48, (array_lava.get(i)).getY() )){
                        Lava lava = new Lava(gp,(array_lava.get(i)).getX() - 48,(array_lava.get(i)).getY());
                        array_lava.set(i,lava);
                    }
                }
            }
            for(Lava lava : array_lava){
                lava.create(g2);
            }
        }
    }
    
    
    
    /*public ArrayList <Integer> DirthAlX= new ArrayList<>();
    public ArrayList <Integer> DirthAlY= new ArrayList<>();
    public ArrayList<Integer> getDirthAlX(){return DirthAlX;}
    public ArrayList<Integer> getDirthAlY(){return DirthAlY;}
    public ArrayList <Rectangle> DirthAl= new ArrayList<>();*/
    
    
    public CopyOnWriteArrayList<Dirth> array_dirth = new CopyOnWriteArrayList<Dirth>();
    public void doPath(MouseHandler m,Graphics2D g2){
        int check = 0 ;
        if (m.getdrag()==true ){
            for(Dirth dirthCheck : array_dirth){
                if(m.getRealX() == dirthCheck.getX() && m.getRealY() == dirthCheck.getY() ){
                    check = 1;
                    break;
                }
            }
            if(check == 0){
                Dirth dirth = new Dirth(gp,m.getRealX(),m.getRealY());
                array_dirth.add(dirth);
            }
            for(Dirth dirthCheck : array_dirth){
                    dirthCheck.create(g2);
                }


            //System.out.println(dirthdx.size());
            //System.out.println(dirthdy.size());
        }
    }
    int stoneX;
    int stoneY;
    public void colisionLavaWater(Graphics2D g2){
        if(array_water.size() != 0 && array_lava.size() != 0){
            for(Water water : array_water){
                int waterX = water.getX();
                int waterY = water.getY();
                for(int i = 0 ; i < array_lava.size() ; i++){
                    if(array_lava.get(i).hasBlock(waterX, waterY) || array_lava.get(i).hasBlock(waterX +48, waterY) || array_lava.get(i).hasBlock(waterX, waterY +48) ||array_lava.get(i).hasBlock(waterX - 48, waterY ) || array_lava.get(i).hasBlock(waterX, waterY - 48)){
                        array_water.removeAll(array_water);
                        array_lava.removeAll(array_lava);
                        stoneX = waterX;
                        stoneY = waterY;
                    
                    }
                }
            }
        }
        
    }
    DefeatScreen defeatScreen = new DefeatScreen();
    
    public CopyOnWriteArrayList<Obsidian> array_obsidian = new CopyOnWriteArrayList<Obsidian>();
    
    int countObsidian = 0 ;
    public void afterColisionLavaWater(Graphics2D g2){
        if(array_water.size() == 0 && array_lava.size() == 0){
            array_obsidian.removeAll(array_obsidian);
            for(int j = 0 ; j < 3 ; j++){
                for(int k =0 ; k < 4 ; k++){
                    //g2.drawImage(tile[1].image,(stoneX-48)+(gp.tileSize*k),(stoneY-48)+(gp.tileSize*j),gp.tileSize,gp.tileSize,null);
                    Obsidian obsidian = new Obsidian(gp,(stoneX-48)+(gp.tileSize*k),(stoneY-48)+(gp.tileSize*j));
                    array_obsidian.add(obsidian);
                    countObsidian++;
                    
                }
            }
            for(Obsidian obsidian : array_obsidian){
                obsidian.create(g2);
            }
            for(Dirth dirth : array_dirth){
            for(int i = 0 ; i < 12 ; i++){
                if(dirth.hasBlock(array_obsidian.get(i).getX(), array_obsidian.get(i).getY())){
                    array_dirth.remove(dirth);
                    break;
                }
            }
        }
        }
        
        /*if(array_obsidian.size() != 0){
            defeatScreen.setVisible(true);
            gp.dispose();
            
        }*/
        
    }
    
    
    
    
    
    
    
}
